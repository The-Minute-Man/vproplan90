import './ktestr.css'

export default function KTestr() {
    return (
    <button>HI</button>
    )
}
